"""
Zero-dependency fallback server for the Flutter code challenge.

Serves the same endpoints as main.py (FastAPI) using only the Python standard
library, so it runs with no `pip install` at all. Use this if you would rather
not set up a virtualenv; prefer main.py (FastAPI) for the nicer docs at /docs.

Run it with:

    cd api
    python3 simple_server.py          # defaults to port 8000
    python3 simple_server.py 9000     # or pass a port

Endpoints match main.py:
    GET /connections
    GET /cities
    GET /assets/cities/*.svg
    GET /health

The API only serves data. The cheapest-route algorithm is intentionally left to
the Flutter candidate to implement and test.
"""

from __future__ import annotations

import json
import re
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

DATA_FILE = Path(__file__).parent / "connections.json"
CITY_ASSETS_DIR = Path(__file__).parent / "assets" / "cities"


def load_connections() -> list[dict]:
    with DATA_FILE.open(encoding="utf-8") as handle:
        return json.load(handle)["connections"]


def cities_from(connections: list[dict]) -> list[str]:
    names: set[str] = set()
    for connection in connections:
        names.add(connection["from"])
        names.add(connection["to"])
    return sorted(names)


def city_slug(city: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", city.lower()).strip("-")


def city_records(connections: list[dict]) -> list[dict]:
    records = []
    for city in cities_from(connections):
        filename = f"{city_slug(city)}.svg"
        if not (CITY_ASSETS_DIR / filename).is_file():
            filename = "default.svg"
        records.append({"name": city, "imageUrl": f"/assets/cities/{filename}"})
    return records


class Handler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        # Mirror the FastAPI CORS policy so Flutter web works too.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_asset(self, path: Path) -> None:
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "image/svg+xml")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 (http.server naming)
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        if path.startswith("/assets/cities/"):
            filename = path.removeprefix("/assets/cities/")
            asset = CITY_ASSETS_DIR / filename
            if (
                filename
                and Path(filename).name == filename
                and asset.suffix == ".svg"
                and asset.is_file()
            ):
                self._send_asset(asset)
            else:
                self._send_json(404, {"error": "Asset not found."})
            return

        connections = load_connections()
        if path == "/health":
            self._send_json(200, {"status": "ok"})
        elif path == "/connections":
            self._send_json(200, {"connections": connections})
        elif path == "/cities":
            self._send_json(200, {"cities": city_records(connections)})
        else:
            self._send_json(404, {"error": f"Unknown path: {path}"})

    def log_message(self, *args: object) -> None:  # quieten default logging
        return


def main() -> None:
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Connections API (stdlib) listening on http://localhost:{port}")
    print("Endpoints: /connections  /cities  /assets/cities/*.svg  /health")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()


if __name__ == "__main__":
    main()
