"""
TUI Mobility Hub – Flutter Code Challenge: local connections API.

A tiny FastAPI service that serves the flight-connection dataset and carousel
images consumed by the Flutter app. It is intentionally small and
dependency-light so candidates spend their time on the Flutter app, not on
backend setup.

Run it with:

    cd api
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    uvicorn main:app --reload --port 8000

Then the data is available at http://localhost:8000/connections

Endpoints
---------
GET /connections            The raw dataset, same shape as the original
                            challenge's connections.json.
GET /cities                 City names with carousel image URLs.
GET /assets/cities/*.svg    The local SVG images used by the carousel.
GET /health                 Liveness check.

The API only serves data. The cheapest-route algorithm is intentionally left to
the Flutter candidate to implement and test. The dataset is loaded from
connections.json next to this file, so you can swap in a different dataset
(different cities/prices/coordinates) without touching the code — the Flutter
app must keep working with whatever this serves.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

DATA_FILE = Path(__file__).parent / "connections.json"
CITY_ASSETS_DIR = Path(__file__).parent / "assets" / "cities"

app = FastAPI(
    title="TUI Mobility Hub – Connections API",
    description="Local flight-connections API for the Flutter code challenge.",
    version="1.0.0",
)

# Flutter web runs in a browser and is subject to CORS; mobile/desktop are not.
# Allowing everything keeps the challenge frictionless on every target. This is
# a local dev service only — do not copy this wide-open policy into production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount(
    "/assets/cities",
    StaticFiles(directory=CITY_ASSETS_DIR),
    name="city-assets",
)


def load_connections() -> list[dict]:
    """Read the dataset from disk on every call.

    Reading per-request (rather than caching at import) means editing
    connections.json is picked up without restarting the server, which makes it
    easy to try the app against different datasets.
    """
    try:
        with DATA_FILE.open(encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError as error:
        raise HTTPException(
            status_code=500,
            detail=f"Dataset not found at {DATA_FILE}",
        ) from error
    except json.JSONDecodeError as error:
        raise HTTPException(
            status_code=500,
            detail=f"Dataset is not valid JSON: {error}",
        ) from error

    connections = data.get("connections")
    if not isinstance(connections, list):
        raise HTTPException(
            status_code=500,
            detail="Dataset must be an object with a 'connections' array.",
        )
    return connections


def cities_from(connections: list[dict]) -> list[str]:
    """Every distinct city appearing as a source or destination, sorted."""
    names: set[str] = set()
    for connection in connections:
        if "from" in connection:
            names.add(connection["from"])
        if "to" in connection:
            names.add(connection["to"])
    return sorted(names)


def city_slug(city: str) -> str:
    """Convert a city name to the filename-safe asset slug."""
    return re.sub(r"[^a-z0-9]+", "-", city.lower()).strip("-")


def city_records(connections: list[dict]) -> list[dict]:
    """Return city names and image URLs for the carousel."""
    records = []
    for city in cities_from(connections):
        filename = f"{city_slug(city)}.svg"
        if not (CITY_ASSETS_DIR / filename).is_file():
            filename = "default.svg"
        records.append({"name": city, "imageUrl": f"/assets/cities/{filename}"})
    return records


@app.get("/health")
def health() -> dict:
    """Liveness check."""
    return {"status": "ok"}


@app.get("/connections")
def get_connections() -> dict:
    """Return the raw dataset, same shape as the original connections.json."""
    return {"connections": load_connections()}


@app.get("/cities")
def get_cities() -> dict:
    """Return sorted city names and carousel image URLs."""
    return {"cities": city_records(load_connections())}
