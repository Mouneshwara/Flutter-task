# Connections API (local)

A tiny local HTTP API that serves the flight-connection dataset and carousel
images for the Flutter code challenge. It replaces the "download a JSON file
from a URL" step so the Flutter app talks to a real running service.

There are two interchangeable implementations serving the **same endpoints** —
pick whichever you prefer:

| File | Needs install? | Notes |
| --- | --- | --- |
| `main.py` (FastAPI) | yes (`pip install`) | Recommended. Interactive docs at `/docs`. |
| `simple_server.py` (stdlib) | no | Zero dependencies, runs on plain Python 3. |

The API intentionally only serves data. The candidate must implement and test
the cheapest-route algorithm in Flutter; no server-side route calculation is
provided.

The dataset lives in `connections.json` and the carousel illustrations live in
`assets/cities/`. Swap `connections.json` for a different dataset and the app
must still work — nothing in the Flutter implementation should be hard-coded.
Cities without a matching illustration receive `default.svg` from the API.

---

## Run it

### Option A — FastAPI (recommended)

```bash
cd api
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Interactive API docs: http://localhost:8000/docs

### Option B — standard library only (no install)

```bash
cd api
python3 simple_server.py          # defaults to port 8000
python3 simple_server.py 9000     # or choose a port
```

---

## Endpoints

| Method & path | Description |
| --- | --- |
| `GET /connections` | The raw dataset, same shape as the original `connections.json`. |
| `GET /cities` | Sorted city names with carousel image URLs. |
| `GET /assets/cities/<file>.svg` | Serves a carousel illustration. |
| `GET /health` | Liveness check. |

Quick check:

```bash
curl http://localhost:8000/connections
curl http://localhost:8000/cities
curl http://localhost:8000/assets/cities/london.svg
curl http://localhost:8000/health
```

### `GET /cities` response

```json
{
  "cities": [
    {
      "name": "London",
      "imageUrl": "/assets/cities/london.svg"
    },
    {
      "name": "Tokyo",
      "imageUrl": "/assets/cities/tokyo.svg"
    }
  ]
}
```

`imageUrl` is a path relative to the API base URL. For example, with the
standard local setup:

```text
http://localhost:8000/assets/cities/london.svg
```

The Flutter app should use the `name` and `imageUrl` values returned by the API
rather than maintaining a hard-coded city-to-image map.

---

## Reaching the API from the Flutter app

The host name depends on where the app runs — this trips people up, so set the
base URL per target:

| Target | Base URL |
| --- | --- |
| iOS simulator | `http://localhost:8000` |
| macOS / desktop / Flutter web | `http://localhost:8000` |
| Android emulator | `http://10.0.2.2:8000` (the emulator's alias for the host) |
| Physical device | `http://<your-computer-LAN-IP>:8000` (same Wi-Fi) |

Tips:
- **Android cleartext:** calling `http://` (not `https`) on Android may need
  `android:usesCleartextTraffic="true"` in the debug manifest, or a
  network-security-config exception.
- **iOS ATS:** `http://localhost` is allowed by default on the simulator.
- **Flutter web:** CORS is already handled — both servers send
  `Access-Control-Allow-Origin: *` (local dev convenience only).
- Make the base URL configurable (e.g. `--dart-define=API_BASE_URL=...`) rather
  than hard-coding it, so switching target or dataset is painless.
