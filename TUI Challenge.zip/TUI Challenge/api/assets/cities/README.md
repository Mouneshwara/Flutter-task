# Carousel city illustrations

Original lightweight SVG illustrations served by the local Connections API for
the challenge carousel. They are intentionally local and deterministic so
candidates do not need to depend on an image CDN.

| City | Asset | API path |
| --- | --- | --- |
| Cape Town | `cape-town.svg` | `/assets/cities/cape-town.svg` |
| London | `london.svg` | `/assets/cities/london.svg` |
| Los Angeles | `los-angeles.svg` | `/assets/cities/los-angeles.svg` |
| New York | `new-york.svg` | `/assets/cities/new-york.svg` |
| Porto | `porto.svg` | `/assets/cities/porto.svg` |
| Sydney | `sydney.svg` | `/assets/cities/sydney.svg` |
| Tokyo | `tokyo.svg` | `/assets/cities/tokyo.svg` |
| Fallback | `default.svg` | `/assets/cities/default.svg` |

Each illustration uses a `1200 × 800` viewBox and is suitable for a wide
carousel card. The artwork is original to this challenge and has no external
image attribution requirement.

The Flutter app should consume the `imageUrl` returned by `GET /cities` instead
of hard-coding these filenames. The files are served by the API and should not
be added to the Flutter asset bundle.
